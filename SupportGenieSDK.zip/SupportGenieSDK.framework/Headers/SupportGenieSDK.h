//
//  SupportGenieSDK.h
//  SupportGenieSDK
//
//  Created by tarun mehta on 10/4/19.
//  Copyright © 2019 SupportGenie. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SupportGenieSDK.
FOUNDATION_EXPORT double SupportGenieSDKVersionNumber;

//! Project version string for SupportGenieSDK.
FOUNDATION_EXPORT const unsigned char SupportGenieSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SupportGenieSDK/PublicHeader.h>


